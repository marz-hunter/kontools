import axios from "axios";
import config from "Config";
import { toast } from "react-toastify";

const api = axios.create({
	baseURL: config.API_URL,
	headers: {
		"Content-type": "application/json; charset=UTF-8",
		"X-Channel": "WEB",
	},
});

api.interceptors.response.use(
	(val) => val,
	(error) => {
		let message = error.response.data.stat_msg;
		if (!message) {
			message = error.toString();
		}

		toast.error(message, { autoClose: false });

		return Promise.reject(error);
	}
);

export default api;
