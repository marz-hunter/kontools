const config = {
	API_URL: process.env.REACT_APP_API_URL,
	AWS_URL_IMAGES: `${process.env.REACT_APP_AWS_URL}/landing`,
};

export default config;
