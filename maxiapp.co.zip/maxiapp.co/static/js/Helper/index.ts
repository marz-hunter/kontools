export const calendlyUrl = "https://calendly.com/hariadi-tjandra/founder-call";

export const onChat = () => {
	window.open("https://api.whatsapp.com/send/?phone=628885591188", "_blank");
};

export const onDownloadApp = () => {
	return window.open("/download-now", "_blank");
};
