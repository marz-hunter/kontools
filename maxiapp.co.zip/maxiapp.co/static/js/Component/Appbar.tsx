import Logo from "../Component/Logo";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faX } from '@fortawesome/free-solid-svg-icons';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { onChat, onDownloadApp } from 'Helper';

const menus = [
    // {
    //     label: "Our Specialists",
    //     link: "/specialist"
    // },
    {
        label: "Maxi for Company",
        link: "/company"
    },
    // {
    //     label: "About Us",
    //     link: "/about"
    // },
];

export default function Appbar(props: { isReverse: boolean; }) {
    const [isHide, setHide] = useState(true);

    const onMenu = () => {
        setHide(!isHide);
    };

    const pathUrl = window.location.pathname;

    return (
        <>
            <div className={ `w-screen h-screen fixed top-0 bg-white z-20` } hidden={ isHide }>
                <header className="wow fadeIn px-2">
                    <div className='flex justify-between'>
                        <Logo></Logo>
                        <FontAwesomeIcon className='cursor-pointer p-4 mt-3' onClick={ onMenu } color="black" icon={ faX } size='lg'></FontAwesomeIcon>
                    </div>
                    <div className='text-center'>
                        {
                            menus.map((val, i) => {
                                return (
                                    <div key={ i }>
                                        <Link to={ val.link }>
                                            <div className={ `py-4 px-4 text-xl cursor-pointer ${val.link === pathUrl ? 'font-semibold' : ''}` }>{ val.label }</div>
                                        </Link>
                                    </div>
                                );
                            })
                        }
                        <div className="mx-6 absolute left-0 right-0 bottom-24">
                            <div className='mb-4 md:mb-0 px-6 py-3 rounded-lg bg-black-app cursor-pointer' onClick={ onDownloadApp }>
                                <div className="leading-6 font-bold text-white">Download App</div>
                            </div>
                            <div className='px-6 py-3 rounded-lg border-black-app border cursor-pointer' onClick={ onChat }>
                                <div className="leading-6 font-bold">Contact Us</div>
                            </div>
                        </div>
                    </div>
                </header>
            </div>

            <header className={ `wow fadeInDown max-w-7xl px-2 lg:px-1 mx-auto flex ${props.isReverse ? 'text-white' : ''}` }>
                <Logo className="md:mx-0"></Logo>
                <div className='flex-grow'></div>
                <div className='block mt-1 lg:hidden'>
                    <FontAwesomeIcon className='cursor-pointer p-4 opacity-70' onClick={ onMenu } color={ `${props.isReverse ? 'white' : 'black'}` } icon={ faBars } size='2x'></FontAwesomeIcon>
                </div>
                <div className='hidden mr-6 lg:block'>
                    <div className='flex gap-8 mt-4'>
                        {
                            menus.map((val, i) => {
                                return (
                                    <div key={ i } className="cursor-pointer">
                                        <Link to={ val.link }>
                                            <div className={ `py-2 px-4 cursor-pointer ${val.link === pathUrl ? 'font-semibold' : ''}` }>{ val.label }</div>
                                        </Link>
                                    </div>
                                );
                            })
                        }
                        <div onClick={ onDownloadApp }>
                            <div className={ `border-2 rounded-lg py-2 px-4 cursor-pointer ${props.isReverse ? 'border-white' : 'border-black/70'}` }>Download App</div>
                        </div>
                    </div>
                </div>
            </header>
        </>
    );
}