import { onChat, onDownloadApp } from 'Helper';
import { Link } from 'react-router-dom';
import { ButtonJoinSpecialist } from './Button';

export function Footer() {
    return (
        <footer>
            <div className="flex max-w-7xl flex-col max-h-full mb-24 justify-between mx-auto px-8 md:flex-row md:max-h-24">
                <div className='mb-6 sm:mb-0 sm:ml-0 text-left max-w-sm'>
                    <Link className='flex' to="/">
                        <img className='w-12' src="/logo192.png" alt="" />
                        <div className='font-bold text-xl mt-3 ml-2'>Maxi</div>
                    </Link>
                    <div className='mt-4'>
                        Bellezza BSA 1st Floor Unit 106, Jl. Letjen Soepeno, Kebayoran Lama
                        Jakarta Selatan 12210
                    </div>
                    <div className="mt-4">Copyright &copy; 2022 Maxi</div>
                </div>
                <div className='flex shrink-0'>
                    <div className='mt-14 md:mt-0 mr-16'>
                        <div className='font-bold text-xl mt-3 mb-4'>Solutions</div>
                        {/* <ul className='text-left hover:text-blue-500 mb-3'>
                            <li><Link to="/specialist" className='hover:underline'>Our Specialist</Link></li>
                        </ul> */}
                        <ul className='text-left hover:text-blue-500'>
                            <li><Link to="/company" className='hover:underline'>Maxi for Company</Link></li>
                        </ul>
                    </div>
                    <div className='mt-14 md:mt-0 md:mr-12'>
                        <div className='font-bold text-xl mt-3 mb-4'>Link</div>
                        {/* <ul className='text-left hover:text-blue-500 mb-3'>
                            <li><Link to="/about" className='hover:underline'>About Us</Link></li>
                        </ul> */}
                        <ul className='text-left hover:text-blue-500 mb-3'>
                            <li><Link to="/privacy" className='hover:underline'>Privacy Statement</Link></li>
                        </ul>
                        <ul className='text-left hover:text-blue-500'>
                            <li><Link to="/term" className='hover:underline'>Terms of Service</Link></li>
                        </ul>
                    </div>
                </div>
                <div className='mt-14 md:mt-0 shrink-0'>
                    <div className='font-bold text-xl mt-3 mb-4'>Social Media</div>
                    <div className="flex flex-row">
                        <a href="https://www.instagram.com/maxiapp.co/" rel='noreferrer' target="__blank">
                            <img className='h-8' src="/images/svg/instagram.svg" alt="" />
                        </a>
                        <a href="https://www.linkedin.com/company/maxiapp/" className='pl-2' rel='noreferrer' target="__blank">
                            <img className='h-8' src="/images/svg/linkedin.svg" alt="" />
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    );
}

export function SectionDemo(props: { className?: string; }) {
    return (
        <section className={ `${props.className}` }>
            <div className="bg-image-line bg-cover bg-center bg-no-repeat mb-20">
                <div className="max-w-2xl mx-auto center pb-24 pt-12">
                    <div className="pt-8 h-28 self-center text-2xl leading-6 px-4 mb-4 sm:mb-6 md:pt-12 md:mb-0">
                        <h2 className='font-bold text-2xl text-left px-6 sm:text-center'>Start your company’s wellbeing journey today</h2>
                    </div>
                    <div className="self-center justify-center gap-2 mx-8 flex flex-col sm:gap-6 sm:mx-0 sm:flex-row">
                        <div className='px-6 py-3 rounded-lg bg-black-app cursor-pointer' onClick={ onDownloadApp }>
                            <p className="leading-6 font-bold text-white">Download App</p>
                        </div>
                        <div className='px-6 py-3 rounded-lg border-black-app border bg-white cursor-pointer' onClick={ onChat }>
                            <div className="leading-6 font-bold">Contact Us</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export function SectionJoinSpecialist(props: { className?: string; }) {
    return (
        <section className={ `${props.className}` }>
            <div className="bg-image-line-greeb bg-cover bg-center bg-no-repeat mb-20">
                <div className="max-w-2xl mx-auto center pb-24 pt-12">
                    <div className="pt-8 h-28 self-center text-2xl leading-6 px-4 mb-4 sm:mb-6 md:pt-12 md:mb-0">
                        <h2 className='font-bold text-2xl text-left px-6 sm:text-center'>Start your company’s wellbeing journey today</h2>
                    </div>
                    <div className="self-center justify-center gap-2 mx-8 flex flex-col sm:gap-6 sm:mx-0 sm:flex-row">
                        <ButtonJoinSpecialist></ButtonJoinSpecialist>
                        <div className='px-6 py-3 rounded-lg border-black-app border bg-white cursor-pointer' onClick={ onChat }>
                            <div className="leading-6 font-bold">Contact Us</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
