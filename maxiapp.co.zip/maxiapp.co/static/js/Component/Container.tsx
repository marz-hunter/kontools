export default function Container(props: { footer?: JSX.Element, children: JSX.Element; }) {
    return (
        <>
            { props.children }
            { props.footer }
        </>
    );
}