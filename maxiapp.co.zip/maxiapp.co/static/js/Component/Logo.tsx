import { Link } from "react-router-dom"

function Logo(props: any) {
    return (
        <Link to="/">
            <img src="/images/Logo Maxi_Logotype.png" className={`w-36 ${props.className ?? ""}`} alt="" />
        </Link>
    )
}

export default Logo