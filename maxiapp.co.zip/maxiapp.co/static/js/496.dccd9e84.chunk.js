"use strict";
(self.webpackChunkmaxiapp_landing = self.webpackChunkmaxiapp_landing || []).push([
    [496], {
        2496: function(e, t, l) {
            l.r(t), l.d(t, {
                default: function() {
                    return _
                }
            });
            var r = l(885),
                n = l(4228),
                a = l(4996),
                c = l(2589),
                o = l(7117),
                s = l(2099),
                i = l(7875),
                d = l(7573),
                m = l(2791),
                u = l(2007),
                p = l.n(u),
                h = ["variant", "color", "size"],
                f = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "m19.5 7.499-1.49 1.49-3-3 1.49-1.49c.42-.42.96-.62 1.5-.62s1.08.2 1.5.62c.83.83.83 2.17 0 3ZM17.31 9.7 6.5 20.5c-.83.83-2.17.83-3 0-.83-.83-.83-2.17 0-3L14.31 6.7l3 3ZM9.95 3.5l.41-1.39c.04-.13 0-.27-.09-.37-.09-.1-.25-.14-.38-.1l-1.39.41-1.39-.41c-.13-.04-.27 0-.37.09-.1.1-.13.24-.09.37l.4 1.4-.41 1.39c-.04.13 0 .27.09.37.1.1.24.13.37.09l1.4-.4 1.39.41c.04.01.07.02.11.02.1 0 .19-.04.27-.11.1-.1.13-.24.09-.37l-.41-1.4ZM5.95 9.5l.41-1.39c.04-.13 0-.27-.09-.37-.1-.1-.24-.13-.37-.09l-1.4.4-1.39-.41c-.13-.04-.27 0-.37.09-.1.1-.13.24-.09.37l.4 1.4-.41 1.39c-.04.13 0 .27.09.37.1.1.24.13.37.09l1.39-.41 1.39.41c.03.01.07.01.11.01.1 0 .19-.04.27-.11.1-.1.13-.24.09-.37l-.4-1.38ZM20.95 14.5l.41-1.39c.04-.13 0-.27-.09-.37-.1-.1-.24-.13-.37-.09l-1.39.41-1.39-.41c-.13-.04-.27 0-.37.09-.1.1-.13.24-.09.37l.41 1.39-.41 1.39c-.04.13 0 .27.09.37.1.1.24.13.37.09l1.39-.41 1.39.41c.03.01.07.01.11.01.1 0 .19-.04.27-.11.1-.1.13-.24.09-.37l-.42-1.38Z",
                        fill: t
                    }))
                },
                x = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "m16.98 10.021 2.52-2.52c.83-.83.83-2.17 0-3-.83-.83-2.17-.83-3 0l-13 13c-.83.83-.83 2.17 0 3 .83.83 2.17.83 3 0l8-8M18.01 8.988l-3-3",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), m.createElement("path", {
                        d: "M9.56 3.5 10 5l-1.5-.44L7 5l.44-1.5L7 2l1.5.44M4.5 8.44 6 8l-.44 1.5L6 11l-1.5-.44L3 11l.44-1.5L3 8l1.5.44ZM18.44 14.5 18 13l1.5.44L21 13l-.44 1.5L21 16l-1.5-.44",
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                g = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "m19.5 7.499-1.49 1.49-3-3 1.49-1.49c.42-.42.96-.62 1.5-.62s1.08.2 1.5.62c.83.83.83 2.17 0 3Z",
                        fill: t
                    }), m.createElement("path", {
                        opacity: ".4",
                        d: "M18.01 8.988 6.5 20.498c-.83.83-2.17.83-3 0-.83-.83-.83-2.17 0-3l11.51-11.51 3 3Z",
                        fill: t
                    }), m.createElement("path", {
                        d: "m9.95 3.5.41-1.39c.04-.13 0-.27-.09-.37-.09-.1-.25-.14-.38-.1l-1.39.41-1.39-.41c-.13-.04-.27 0-.37.09-.1.1-.13.24-.09.37l.4 1.4-.41 1.39c-.04.13 0 .27.09.37.1.1.24.13.37.09l1.4-.4 1.39.41c.04.01.07.02.11.02.1 0 .19-.04.27-.11.1-.1.13-.24.09-.37l-.41-1.4ZM5.95 9.5l.41-1.39c.04-.13 0-.27-.09-.37-.1-.1-.24-.13-.37-.09l-1.4.4-1.39-.41c-.13-.04-.27 0-.37.09-.1.1-.13.24-.09.37l.4 1.4-.41 1.39c-.04.13 0 .27.09.37.1.1.24.13.37.09l1.39-.41 1.39.41c.03.01.07.01.11.01.1 0 .19-.04.27-.11.1-.1.13-.24.09-.37l-.4-1.38ZM20.95 14.5l.41-1.39c.04-.13 0-.27-.09-.37-.1-.1-.24-.13-.37-.09l-1.39.41-1.39-.41c-.13-.04-.27 0-.37.09-.1.1-.13.24-.09.37l.41 1.39-.41 1.39c-.04.13 0 .27.09.37.1.1.24.13.37.09l1.39-.41 1.39.41c.03.01.07.01.11.01.1 0 .19-.04.27-.11.1-.1.13-.24.09-.37l-.42-1.38Z",
                        fill: t
                    }))
                },
                v = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "1.5",
                        d: "M3.5 20.5c.83.83 2.17.83 3 0l13-13c.83-.83.83-2.17 0-3-.83-.83-2.17-.83-3 0l-13 13c-.83.83-.83 2.17 0 3zM18.01 8.99l-3-3"
                    }), m.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M8.5 2.44L10 2l-.44 1.5L10 5l-1.5-.44L7 5l.44-1.5L7 2l1.5.44zM4.5 8.44L6 8l-.44 1.5L6 11l-1.5-.44L3 11l.44-1.5L3 8l1.5.44zM19.5 13.44L21 13l-.44 1.5L21 16l-1.5-.44L18 16l.44-1.5L18 13l1.5.44z"
                    }))
                },
                k = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "M5 21.869c-.74 0-1.47-.28-2.03-.84-.54-.54-.84-1.26-.84-2.03 0-.77.3-1.49.84-2.03l13-13a2.873 2.873 0 0 1 4.06 0c.54.54.84 1.26.84 2.03 0 .77-.3 1.49-.84 2.03l-13 13c-.56.56-1.29.84-2.03.84Zm13-17.24c-.35 0-.7.13-.97.4l-13 13c-.26.26-.4.6-.4.97s.14.71.4.97c.53.53 1.41.53 1.94 0l13-13c.26-.26.4-.6.4-.97s-.14-.71-.4-.97c-.27-.27-.62-.4-.97-.4Z",
                        fill: t
                    }), m.createElement("path", {
                        d: "M18.01 9.74c-.19 0-.38-.07-.53-.22l-3-3a.754.754 0 0 1 0-1.06c.29-.29.77-.29 1.06 0l3 3c.29.29.29.77 0 1.06-.15.15-.34.22-.53.22ZM10 5.5c-.05 0-.09-.01-.14-.02l-1.36-.4-1.36.4c-.18.05-.37 0-.49-.13-.13-.13-.18-.31-.13-.49l.4-1.36-.4-1.36c-.05-.18 0-.37.13-.49a.5.5 0 0 1 .49-.13l1.36.4 1.36-.4c.18-.05.36 0 .49.13a.5.5 0 0 1 .13.49l-.4 1.36.4 1.36c.05.18 0 .37-.13.49a.47.47 0 0 1-.35.15ZM8.5 4.06c.05 0 .09.01.14.02l.62.18-.18-.62a.447.447 0 0 1 0-.28l.18-.62-.62.18c-.09.03-.19.03-.28 0l-.62-.18.18.62c.03.09.03.19 0 .28l-.18.62.62-.18c.05-.01.09-.02.14-.02ZM6 11.5c-.05 0-.09-.01-.14-.02l-1.36-.4-1.36.4c-.18.05-.36 0-.49-.13a.5.5 0 0 1-.13-.49l.4-1.36-.4-1.36c-.05-.18 0-.37.13-.49s.32-.18.49-.13l1.36.4 1.36-.4a.5.5 0 0 1 .49.13c.13.13.18.32.13.49l-.4 1.36.4 1.36c.05.18 0 .37-.13.49a.47.47 0 0 1-.35.15Zm-1.5-1.44c.05 0 .09.01.14.02l.62.18-.18-.62a.447.447 0 0 1 0-.28l.18-.62-.62.18c-.09.03-.19.03-.28 0l-.62-.18.18.62c.03.09.03.19 0 .28l-.18.62.62-.18c.05-.01.09-.02.14-.02ZM21 16.5c-.05 0-.09-.01-.14-.02l-1.36-.4-1.36.4c-.18.05-.36 0-.49-.13s-.18-.32-.13-.49l.4-1.36-.4-1.36c-.05-.18 0-.37.13-.49s.32-.18.49-.13l1.36.4 1.36-.4a.5.5 0 0 1 .49.13.5.5 0 0 1 .13.49l-.4 1.36.4 1.36c.05.18 0 .37-.13.49a.47.47 0 0 1-.35.15Zm-1.5-1.44c.05 0 .09.01.14.02l.62.18-.18-.62a.447.447 0 0 1 0-.28l.18-.62-.62.18c-.09.03-.19.03-.28 0l-.62-.18.18.62c.03.09.03.19 0 .28l-.18.62.62-.18c.05-.01.09-.02.14-.02Z",
                        fill: t
                    }))
                },
                j = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "M3.5 20.501c.83.83 2.17.83 3 0l13-13c.83-.83.83-2.17 0-3-.83-.83-2.17-.83-3 0l-13 13c-.83.83-.83 2.17 0 3Z",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), m.createElement("path", {
                        opacity: ".4",
                        d: "m18.01 8.988-3-3",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), m.createElement("path", {
                        opacity: ".4",
                        d: "M8.5 2.44 10 2l-.44 1.5L10 5l-1.5-.44L7 5l.44-1.5L7 2l1.5.44ZM4.5 8.44 6 8l-.44 1.5L6 11l-1.5-.44L3 11l.44-1.5L3 8l1.5.44ZM19.5 13.44 21 13l-.44 1.5L21 16l-1.5-.44L18 16l.44-1.5L18 13l1.5.44Z",
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                b = (0, m.forwardRef)((function(e, t) {
                    var l = e.variant,
                        r = e.color,
                        n = e.size,
                        a = (0, d._)(e, h);
                    return m.createElement("svg", (0, d.a)({}, a, {
                        xmlns: "http://www.w3.org/2000/svg",
                        ref: t,
                        width: n,
                        height: n,
                        viewBox: "0 0 24 24",
                        fill: "none"
                    }), function(e, t) {
                        switch (e) {
                            case "Bold":
                                return m.createElement(f, {
                                    color: t
                                });
                            case "Broken":
                                return m.createElement(x, {
                                    color: t
                                });
                            case "Bulk":
                                return m.createElement(g, {
                                    color: t
                                });
                            case "Linear":
                            default:
                                return m.createElement(v, {
                                    color: t
                                });
                            case "Outline":
                                return m.createElement(k, {
                                    color: t
                                });
                            case "TwoTone":
                                return m.createElement(j, {
                                    color: t
                                })
                        }
                    }(l, r))
                }));
            b.propTypes = {
                variant: p().oneOf(["Linear", "Bold", "Broken", "Bulk", "Outline", "TwoTone"]),
                color: p().string,
                size: p().oneOfType([p().string, p().number])
            }, b.defaultProps = {
                variant: "Linear",
                color: "currentColor",
                size: "24"
            }, b.displayName = "Magicpen";
            var w = ["variant", "color", "size"],
                E = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "m21.56 10.739-1.36-1.58c-.26-.3-.47-.86-.47-1.26v-1.7c0-1.06-.87-1.93-1.93-1.93h-1.7c-.39 0-.96-.21-1.26-.47l-1.58-1.36c-.69-.59-1.82-.59-2.52 0l-1.57 1.37c-.3.25-.87.46-1.26.46H6.18c-1.06 0-1.93.87-1.93 1.93v1.71c0 .39-.21.95-.46 1.25l-1.35 1.59c-.58.69-.58 1.81 0 2.5l1.35 1.59c.25.3.46.86.46 1.25v1.71c0 1.06.87 1.93 1.93 1.93h1.73c.39 0 .96.21 1.26.47l1.58 1.36c.69.59 1.82.59 2.52 0l1.58-1.36c.3-.26.86-.47 1.26-.47h1.7c1.06 0 1.93-.87 1.93-1.93v-1.7c0-.39.21-.96.47-1.26l1.36-1.58c.58-.69.58-1.83-.01-2.52Zm-5.4-.63-4.83 4.83a.75.75 0 0 1-1.06 0l-2.42-2.42a.754.754 0 0 1 0-1.06c.29-.29.77-.29 1.06 0l1.89 1.89 4.3-4.3c.29-.29.77-.29 1.06 0 .29.29.29.77 0 1.06Z",
                        fill: t
                    }))
                },
                y = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "m8.38 11.998 2.41 2.42 4.83-4.84",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), m.createElement("path", {
                        d: "M4.24 6.198c0-1.06.87-1.93 1.93-1.93H7.9c.4 0 .96-.21 1.26-.46l1.58-1.35c.7-.59 1.83-.59 2.51 0l1.58 1.35c.3.25.87.46 1.27.46h1.7c1.06 0 1.93.87 1.93 1.93v1.7c0 .4.21.96.46 1.26l1.35 1.58c.59.7.59 1.83 0 2.51l-1.35 1.58c-.25.3-.46.86-.46 1.26v1.7c0 1.06-.87 1.93-1.93 1.93h-1.7c-.4 0-.96.21-1.26.46l-1.58 1.35c-.7.59-1.83.59-2.51 0l-1.58-1.35c-.3-.25-.87-.46-1.26-.46H6.17c-1.06 0-1.93-.87-1.93-1.93v-1.71c0-.39-.2-.96-.45-1.25l-1.35-1.59c-.58-.69-.58-1.81 0-2.5l.56-.66",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                L = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        opacity: ".4",
                        d: "M10.75 2.45c.69-.59 1.82-.59 2.52 0l1.58 1.36c.3.26.86.47 1.26.47h1.7c1.06 0 1.93.87 1.93 1.93v1.7c0 .39.21.96.47 1.26l1.36 1.58c.59.69.59 1.82 0 2.52l-1.36 1.58c-.26.3-.47.86-.47 1.26v1.7c0 1.06-.87 1.93-1.93 1.93h-1.7c-.39 0-.96.21-1.26.47l-1.58 1.36c-.69.59-1.82.59-2.52 0l-1.58-1.36c-.3-.26-.86-.47-1.26-.47H6.18c-1.06 0-1.93-.87-1.93-1.93V16.1c0-.39-.21-.95-.46-1.25l-1.35-1.59c-.58-.69-.58-1.81 0-2.5l1.35-1.59c.25-.3.46-.86.46-1.25V6.2c0-1.06.87-1.93 1.93-1.93h1.73c.39 0 .96-.21 1.26-.47l1.58-1.35Z",
                        fill: t
                    }), m.createElement("path", {
                        d: "M10.79 15.171a.75.75 0 0 1-.53-.22l-2.42-2.42a.754.754 0 0 1 0-1.06c.29-.29.77-.29 1.06 0l1.89 1.89 4.3-4.3c.29-.29.77-.29 1.06 0 .29.29.29.77 0 1.06l-4.83 4.83a.75.75 0 0 1-.53.22Z",
                        fill: t
                    }))
                },
                N = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "m8.38 12 2.41 2.42 4.83-4.84",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), m.createElement("path", {
                        d: "M10.75 2.45c.69-.59 1.82-.59 2.52 0l1.58 1.36c.3.26.86.47 1.26.47h1.7c1.06 0 1.93.87 1.93 1.93v1.7c0 .39.21.96.47 1.26l1.36 1.58c.59.69.59 1.82 0 2.52l-1.36 1.58c-.26.3-.47.86-.47 1.26v1.7c0 1.06-.87 1.93-1.93 1.93h-1.7c-.39 0-.96.21-1.26.47l-1.58 1.36c-.69.59-1.82.59-2.52 0l-1.58-1.36c-.3-.26-.86-.47-1.26-.47H6.18c-1.06 0-1.93-.87-1.93-1.93V16.1c0-.39-.21-.95-.46-1.25l-1.35-1.59c-.58-.69-.58-1.81 0-2.5l1.35-1.59c.25-.3.46-.86.46-1.25V6.2c0-1.06.87-1.93 1.93-1.93h1.73c.39 0 .96-.21 1.26-.47l1.58-1.35Z",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                M = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        d: "M10.79 15.171a.75.75 0 0 1-.53-.22l-2.42-2.42a.754.754 0 0 1 0-1.06c.29-.29.77-.29 1.06 0l1.89 1.89 4.3-4.3c.29-.29.77-.29 1.06 0 .29.29.29.77 0 1.06l-4.83 4.83a.75.75 0 0 1-.53.22Z",
                        fill: t
                    }), m.createElement("path", {
                        d: "M12 22.75c-.63 0-1.26-.21-1.75-.63l-1.58-1.36c-.16-.14-.56-.28-.77-.28H6.18A2.68 2.68 0 0 1 3.5 17.8v-1.71c0-.21-.14-.6-.28-.76l-1.35-1.59c-.82-.97-.82-2.5 0-3.47l1.35-1.59c.14-.16.28-.55.28-.76V6.2c0-1.48 1.2-2.68 2.68-2.68h1.73c.21 0 .61-.15.77-.28l1.58-1.36c.98-.84 2.51-.84 3.49 0l1.58 1.36c.16.14.56.28.77.28h1.7c1.48 0 2.68 1.2 2.68 2.68v1.7c0 .21.15.61.29.77l1.36 1.58c.84.98.84 2.51 0 3.49l-1.36 1.58c-.14.16-.29.56-.29.77v1.7c0 1.48-1.2 2.68-2.68 2.68h-1.7c-.21 0-.61.15-.77.28l-1.58 1.36c-.49.43-1.12.64-1.75.64ZM6.18 5.02C5.53 5.02 5 5.55 5 6.2v1.71c0 .57-.27 1.3-.64 1.73l-1.35 1.59c-.35.41-.35 1.12 0 1.53l1.35 1.59c.37.44.64 1.16.64 1.73v1.71c0 .65.53 1.18 1.18 1.18h1.73c.58 0 1.31.27 1.75.65l1.58 1.36c.41.35 1.13.35 1.54 0l1.58-1.36c.44-.37 1.17-.65 1.75-.65h1.7c.65 0 1.18-.53 1.18-1.18v-1.7c0-.58.27-1.31.65-1.75L21 12.76c.35-.41.35-1.13 0-1.54l-1.36-1.58c-.38-.44-.65-1.17-.65-1.75V6.2c0-.65-.53-1.18-1.18-1.18h-1.7c-.58 0-1.31-.27-1.75-.65l-1.58-1.36c-.41-.35-1.13-.35-1.54 0L9.66 4.38c-.44.37-1.18.64-1.75.64H6.18Z",
                        fill: t
                    }))
                },
                Z = function(e) {
                    var t = e.color;
                    return m.createElement(m.Fragment, null, m.createElement("path", {
                        opacity: ".34",
                        d: "m8.38 11.998 2.41 2.42 4.83-4.84",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), m.createElement("path", {
                        d: "M10.75 2.45c.69-.59 1.82-.59 2.52 0l1.58 1.36c.3.26.86.47 1.26.47h1.7c1.06 0 1.93.87 1.93 1.93v1.7c0 .39.21.96.47 1.26l1.36 1.58c.59.69.59 1.82 0 2.52l-1.36 1.58c-.26.3-.47.86-.47 1.26v1.7c0 1.06-.87 1.93-1.93 1.93h-1.7c-.39 0-.96.21-1.26.47l-1.58 1.36c-.69.59-1.82.59-2.52 0l-1.58-1.36c-.3-.26-.86-.47-1.26-.47H6.18c-1.06 0-1.93-.87-1.93-1.93V16.1c0-.39-.21-.95-.46-1.25l-1.35-1.59c-.58-.69-.58-1.81 0-2.5l1.35-1.59c.25-.3.46-.86.46-1.25V6.2c0-1.06.87-1.93 1.93-1.93h1.73c.39 0 .96-.21 1.26-.47l1.58-1.35Z",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                z = (0, m.forwardRef)((function(e, t) {
                    var l = e.variant,
                        r = e.color,
                        n = e.size,
                        a = (0, d._)(e, w);
                    return m.createElement("svg", (0, d.a)({}, a, {
                        xmlns: "http://www.w3.org/2000/svg",
                        ref: t,
                        width: n,
                        height: n,
                        viewBox: "0 0 24 24",
                        fill: "none"
                    }), function(e, t) {
                        switch (e) {
                            case "Bold":
                                return m.createElement(E, {
                                    color: t
                                });
                            case "Broken":
                                return m.createElement(y, {
                                    color: t
                                });
                            case "Bulk":
                                return m.createElement(L, {
                                    color: t
                                });
                            case "Linear":
                            default:
                                return m.createElement(N, {
                                    color: t
                                });
                            case "Outline":
                                return m.createElement(M, {
                                    color: t
                                });
                            case "TwoTone":
                                return m.createElement(Z, {
                                    color: t
                                })
                        }
                    }(l, r))
                }));
            z.propTypes = {
                variant: p().oneOf(["Linear", "Bold", "Broken", "Bulk", "Outline", "TwoTone"]),
                color: p().string,
                size: p().oneOfType([p().string, p().number])
            }, z.defaultProps = {
                variant: "Linear",
                color: "currentColor",
                size: "24"
            }, z.displayName = "Verify";
            var F = l(90),
                B = l(4570),
                C = l(4270),
                O = [{
                    title: "Personalised Care",
                    subtitle: "Maxi is a wellbeing platform that helps you live your best life",
                    imageUrl: ""
                }, {
                    title: "Self Screening",
                    subtitle: "Online screening is one of the quickest and easiest ways to test if you need to seek further help.",
                    imageUrl: "/images/home/bg_personalise1.png"
                }, {
                    title: "Private Counseling",
                    subtitle: "Access our list of trained counselors, licensed psychologists and certified coaches.",
                    imageUrl: "/images/home/bg_personalise2.png"
                }, {
                    title: "Guided Exercises",
                    subtitle: "Fostering connection and support through guided exercise on your wellbeing challenges.",
                    imageUrl: "/images/home/bg_personalise3.png"
                }],
                S = [{
                    title: "Counselors",
                    desc: "Counselors help you manage personal issues such as anxiety and stress, and educate you on strategies that can help you overcome your problems."
                }, {
                    title: "Psychologists",
                    desc: "Psychologists help assess and diagnose your mental, physical or behavioral health issues and develop treatment plans for you."
                }, {
                    title: "Coaches",
                    desc: "Coaches help clarify your goals, identify obstacles and create actionable plans to help you reach your goals."
                }],
                T = [{
                    name: "BP",
                    position: "26 Years Old, Male, Professional",
                    subtitle: "For those of you who needs counseling for life, relationship and work issues... don\u2019t give up! Maxi counselors are very helpful!"
                }, {
                    name: "NR",
                    position: "30 Years Old, Female, HR Lead",
                    subtitle: "Maxi provides a better solution for an Employee Wellbeing with a more competitive price and better treatment."
                }, {
                    name: "SA",
                    position: "24 Years Old, Female, CEO",
                    subtitle: "It is my first time of having a platform to take care of my mental health, and I\u2019m satisfied with how Maxi Counsellor handled the session."
                }, {
                    name: "DR",
                    position: "20 Years Old, Female, Student",
                    subtitle: "Maxi helps me to gain my confidence to speak about what I truly feel, not only by experiencing their counselling session, but the features also makes us feel secure."
                }],
                W = l(184);

            function _() {
                return (0, W.jsxs)("div", {
                    children: [(0, W.jsxs)(C.q, {
                        children: [(0, W.jsx)("title", {
                            children: "MAXI: Think & Perform Better"
                        }), (0, W.jsx)("meta", {
                            name: "description",
                            content: "Maxiapp or mental health app is An anonymous work-life community platform that improves employee mental wellness and productivity. Maxiapp is your supportive partner that can help you build a happier workplace and trust with your employees."
                        })]
                    }), (0, W.jsxs)("div", {
                        className: "text-center",
                        children: [(0, W.jsxs)("div", {
                            style: {
                                backgroundImage: "url('".concat(o.Z.AWS_URL_IMAGES, "/images/employer/bg_home.png')"),
                                backgroundSize: "cover",
                                backgroundPosition: "center top"
                            },
                            children: [(0, W.jsx)(n.Z, {
                                isReverse: !1
                            }), (0, W.jsx)(A, {
                                className: "wow fadeInDown"
                            }), (0, W.jsx)(P, {
                                className: "wow fadeInDown"
                            })]
                        }), (0, W.jsx)(I, {
                            className: "wow fadeInDown"
                        }), (0, W.jsx)(R, {
                            className: "wow fadeInDown"
                        }), (0, W.jsx)(D, {
                            className: "wow fadeInDown"
                        }), (0, W.jsx)(c.kg, {
                            className: "wow fadeInDown"
                        })]
                    })]
                })
            }

            function A(e) {
                function t(e) {
                    return (0, W.jsxs)("div", {
                        className: "text-left",
                        children: [(0, W.jsxs)("div", {
                            className: "flex mb-4",
                            children: [(0, W.jsx)("div", {
                                className: "h-14 w-14 rounded-full p-4",
                                style: {
                                    backgroundColor: "#D2EDF9"
                                },
                                children: e.icon
                            }), (0, W.jsxs)("div", {
                                className: "ml-4 flex flex-col justify-center",
                                children: [(0, W.jsx)("div", {
                                    className: "text-2xl font-medium",
                                    children: e.title
                                }), (0, W.jsx)("div", {
                                    className: "text-black-app/60 mt-2 lg:hidden",
                                    children: e.subtitle
                                })]
                            })]
                        }), (0, W.jsx)("div", {
                            className: "text-black-app/60 ml-16 pl-2 hidden lg:block lg:ml-0 lg:pl-0",
                            children: e.subtitle
                        })]
                    })
                }
                return (0, W.jsx)("section", {
                    className: "".concat(e.className),
                    children: (0, W.jsxs)("article", {
                        children: [(0, W.jsxs)("div", {
                            className: "max-w-7xl mx-auto px-6 mb-20 lg:mb-0 lg:py-28 pt-8 lg:flex lg:max-h-600 overflow-hidden",
                            children: [(0, W.jsx)("div", {
                                className: "lg:w-1/2 lg:order-last",
                                children: (0, W.jsx)("div", {
                                    className: "flex justify-center",
                                    children: (0, W.jsx)("div", {
                                        className: "w-40 lg:w-96",
                                        children: (0, W.jsx)("img", {
                                            className: "",
                                            src: "/images/home/bg_phone.png",
                                            alt: ""
                                        })
                                    })
                                })
                            }), (0, W.jsxs)("div", {
                                className: "mt-6 lg:mt-8 lg:w-1/2",
                                children: [(0, W.jsxs)("div", {
                                    className: "text-center mx-auto max-w-lg lg:mx-0 lg:text-left",
                                    children: [(0, W.jsx)("h1", {
                                        className: "text-4xl p-0 !leading-snug font-semibold md:text-5xl",
                                        children: "Your wellbeing partner for life"
                                    }), (0, W.jsx)("p", {
                                        className: "!my-5 pb-2 opacity-80",
                                        children: "Check in daily and receive recommendations for your wellbeing"
                                    })]
                                }), (0, W.jsxs)("div", {
                                    className: "mx-auto self-center justify-center sm:flex lg:justify-start gap-4",
                                    children: [(0, W.jsx)("div", {
                                        className: "mb-4 sm:mb-0 px-6 py-3 rounded-lg bg-black-app cursor-pointer",
                                        onClick: s.kn,
                                        children: (0, W.jsx)("div", {
                                            className: "leading-6 font-bold text-white",
                                            children: "Download App"
                                        })
                                    }), (0, W.jsx)("div", {
                                        className: "cursor-pointer px-6 py-3 rounded-lg border border-black-app/50",
                                        onClick: s.SS,
                                        children: (0, W.jsx)("div", {
                                            className: "leading-6 font-bold",
                                            children: "Contact Us"
                                        })
                                    })]
                                })]
                            })]
                        }), (0, W.jsx)("div", {
                            style: {
                                backgroundColor: "#F3F5F9"
                            },
                            children: (0, W.jsxs)("div", {
                                className: "max-w-7xl mx-auto flex flex-col px-6 py-24 gap-6 lg:flex-row lg:gap-24",
                                children: [(0, W.jsx)("div", {
                                    className: "basis-1/3",
                                    children: (0, W.jsx)(t, {
                                        title: "Check-in your mood",
                                        subtitle: "Find the right words to describe your feelings and triggers",
                                        icon: (0, W.jsx)(i.Z, {
                                            variant: "Bold"
                                        })
                                    })
                                }), (0, W.jsx)("div", {
                                    className: "basis-1/3",
                                    children: (0, W.jsx)(t, {
                                        title: "Get recommendations",
                                        subtitle: "Get recommended strategies to improve your mood",
                                        icon: (0, W.jsx)(b, {
                                            variant: "Bold"
                                        })
                                    })
                                }), (0, W.jsx)("div", {
                                    className: "basis-1/3",
                                    children: (0, W.jsx)(t, {
                                        title: "Explore resources",
                                        subtitle: "Access a wide selection of care resources",
                                        icon: (0, W.jsx)(z, {
                                            variant: "Bold"
                                        })
                                    })
                                })]
                            })
                        })]
                    })
                })
            }

            function P(e) {
                var t = function(e) {
                        return (0, W.jsxs)("div", {
                            className: "rounded-3xl shadow-sm bg-white text-left mr-8 w-full mb-12 md:w-72",
                            children: [(0, W.jsx)("img", {
                                className: "w-full rounded-t-3xl",
                                src: e.imageUrl,
                                alt: ""
                            }), (0, W.jsxs)("div", {
                                className: "px-5 pb-9",
                                children: [(0, W.jsx)("div", {
                                    className: "mt-4 text-2xl font-semibold",
                                    children: e.title
                                }), (0, W.jsx)("div", {
                                    className: "mt-2 text-slate-800",
                                    children: e.subtitle
                                })]
                            })]
                        })
                    },
                    l = function(e) {
                        return (0, W.jsxs)("div", {
                            className: "text-left w-full mr-8 mb-12 md:w-80",
                            children: [(0, W.jsx)("div", {
                                className: "text-2xl font-semibold",
                                children: e.title
                            }), (0, W.jsx)("div", {
                                className: "mt-4 mb-8",
                                children: e.subtitle
                            }), (0, W.jsx)("div", {
                                className: "flex",
                                children: (0, W.jsx)(a.wZ, {})
                            })]
                        })
                    };
                return (0, W.jsx)("section", {
                    className: e.className,
                    children: (0, W.jsx)("div", {
                        className: "py-20 overflow-x-scroll",
                        children: (0, W.jsx)("div", {
                            className: "px-6 mx-auto max-w-7xl",
                            children: (0, W.jsx)("div", {
                                className: "flex flex-col md:flex-row justify-center",
                                children: O.map((function(e, r) {
                                    return 0 === r ? (0, W.jsx)(l, {
                                        title: e.title,
                                        subtitle: e.subtitle
                                    }, r) : (0, W.jsx)(t, {
                                        imageUrl: e.imageUrl,
                                        title: e.title,
                                        subtitle: e.subtitle
                                    }, r)
                                }))
                            })
                        })
                    })
                })
            }

            function I(e) {
                var t = function(e) {
                    return (0, W.jsxs)("div", {
                        className: "flex gap-5 mb-8",
                        children: [(0, W.jsx)("div", {
                            className: "h-5 w-5 shrink-0",
                            children: (0, W.jsx)("img", {
                                className: "w-full h-full",
                                style: {
                                    marginTop: "2px"
                                },
                                src: "".concat(o.Z.AWS_URL_IMAGES, "/images/employee/icon_check.svg"),
                                alt: ""
                            })
                        }), (0, W.jsxs)("div", {
                            children: [(0, W.jsx)("div", {
                                children: e.title
                            }), (0, W.jsx)("div", {
                                className: "opacity-60 mt-2",
                                children: e.desc
                            })]
                        })]
                    })
                };
                return (0, W.jsx)("section", {
                    className: e.className,
                    children: (0, W.jsx)("article", {
                        children: (0, W.jsx)("div", {
                            className: "bg-slate-100 py-20",
                            children: (0, W.jsx)("div", {
                                className: "max-w-7xl mx-auto p-6",
                                children: (0, W.jsxs)("div", {
                                    className: "flex flex-col lg:flex-row gap-16",
                                    children: [(0, W.jsx)("div", {
                                        className: "basis-1/2 flex gap-9",
                                        children: (0, W.jsx)("img", {
                                            className: "object-fill",
                                            src: "/images/home/bg_supporttype1.png",
                                            alt: ""
                                        })
                                    }), (0, W.jsxs)("div", {
                                        className: "text-left basis-1/2",
                                        children: [(0, W.jsx)("div", {
                                            className: "text-2xl font-semibold mb-4",
                                            children: "Counselors, Psychologists, and Coaches"
                                        }), (0, W.jsx)("div", {
                                            className: "opacity-75 mb-10",
                                            children: "Match with our specialists and access on-demand support through voice call or video call."
                                        }), (0, W.jsx)("div", {
                                            children: S.map((function(e, l) {
                                                return (0, W.jsx)(t, {
                                                    title: e.title,
                                                    desc: e.desc
                                                }, l)
                                            }))
                                        })]
                                    })]
                                })
                            })
                        })
                    })
                })
            }

            function R(e) {
                var t = (0, m.useState)(0),
                    l = (0, r.Z)(t, 2),
                    n = l[0],
                    a = l[1],
                    c = (0, m.useRef)(null),
                    o = function(e) {
                        return (0, W.jsxs)("div", {
                            className: "w-80 md:w-96 shrink-0 px-8 py-10 mr-8 rounded-lg",
                            style: {
                                backgroundColor: "#F3F5F9"
                            },
                            children: [(0, W.jsx)("div", {
                                className: "pb-12 border-b border-black-app/40 opacity-60 h-36",
                                children: e.testimony
                            }), (0, W.jsx)("div", {
                                className: "font-semibold text-lg mb-2 mt-4",
                                children: e.name
                            }), (0, W.jsx)("div", {
                                className: "opacity-50",
                                children: e.position
                            })]
                        })
                    };
                return (0, W.jsx)("section", {
                    className: e.className,
                    children: (0, W.jsx)("article", {
                        className: "",
                        children: (0, W.jsxs)("div", {
                            className: "max-w-7xl mx-auto pt-32 pb-24 relative",
                            children: [(0, W.jsx)("div", {
                                className: "absolute left-8 top-32 text-left w-80",
                                children: (0, W.jsx)("div", {
                                    className: "text-2xl font-semibold mb-6 mt-14",
                                    children: "What our users say"
                                })
                            }), (0, W.jsx)("div", {
                                className: "absolute bottom-16 left-8 md:bottom-32",
                                children: (0, W.jsxs)("div", {
                                    className: "flex gap-4",
                                    children: [(0, W.jsx)(F.Z, {
                                        className: "".concat(0 === n ? "text-neutral-300" : "cursor-pointer"),
                                        variant: "Bold",
                                        size: 42,
                                        onClick: function() {
                                            var e;
                                            if (0 !== n) {
                                                var t = n - 1;
                                                null === (e = c.current) || void 0 === e || e.scrollTo({
                                                    left: 320 * t,
                                                    behavior: "smooth"
                                                }), a(t)
                                            }
                                        }
                                    }), (0, W.jsx)(B.Z, {
                                        className: "".concat(3 === n ? "text-neutral-300" : "cursor-pointer"),
                                        variant: "Bold",
                                        size: 42,
                                        onClick: function() {
                                            var e;
                                            if (3 !== n) {
                                                var t = n + 1;
                                                null === (e = c.current) || void 0 === e || e.scrollTo({
                                                    left: 320 * t,
                                                    behavior: "smooth"
                                                }), a(t)
                                            }
                                        }
                                    })]
                                })
                            }), (0, W.jsx)("div", {
                                className: "flex shrink-0 overflow-x-hidden px-8 text-left ml-0 mt-40 md:ml-96 md:mt-0 md:px-0",
                                ref: c,
                                children: T.map((function(e, t) {
                                    return (0, W.jsx)(o, {
                                        testimony: e.subtitle,
                                        name: e.name,
                                        position: e.position
                                    }, t)
                                }))
                            })]
                        })
                    })
                })
            }

            function D(e) {
                return (0, W.jsx)("section", {
                    className: e.className,
                    children: (0, W.jsx)("div", {
                        className: "mx-12 mb-32",
                        children: (0, W.jsxs)("div", {
                            className: "mx-auto px-4 rounded-3xl max-w-7xl mt-12 text-left relative bg-blue-background lg:mt-20 lg:pb-8 lg:mb-0",
                            children: [(0, W.jsxs)("div", {
                                className: "px-8 pt-10 pb-4 mb-14 lg:mb-0 lg:pb-6 lg:p-16 lg:w-1/2",
                                children: [(0, W.jsx)("div", {
                                    className: "text-2xl font-medium text-black-app",
                                    children: "Download our app from the App Store & Google Play"
                                }), (0, W.jsx)("div", {
                                    className: "mt-4 opacity-60 mb-8",
                                    children: "Start your wellbeing journey today"
                                }), (0, W.jsxs)("div", {
                                    className: "flex flex-col gap-4 md:flex-row md:gap-10",
                                    children: [(0, W.jsx)("a", {
                                        href: "https://play.app.goo.gl/?link=https://play.google.com/store/apps/details?id=com.rebelworks.maxi_app_prod",
                                        children: (0, W.jsx)("div", {
                                            className: "cursor-pointer",
                                            children: (0, W.jsx)("img", {
                                                src: "/images/playstore.png",
                                                alt: ""
                                            })
                                        })
                                    }), (0, W.jsx)("a", {
                                        href: "https://apps.apple.com/id/app/maxi-think-perform-better/id1632571529?itsct=apps_box_link&itscg=30200",
                                        children: (0, W.jsx)("div", {
                                            className: "cursor-pointer",
                                            children: (0, W.jsx)("img", {
                                                src: "/images/appstore.png",
                                                alt: ""
                                            })
                                        })
                                    })]
                                })]
                            }), (0, W.jsx)("div", {
                                className: "flex justify-center lg:hidden",
                                children: (0, W.jsx)("img", {
                                    src: "/images/home/bg_download.png",
                                    alt: ""
                                })
                            }), (0, W.jsx)("img", {
                                className: "z-10 absolute origin-bottom scale-125 right-24 bottom-0 h-full hidden lg:block",
                                src: "/images/home/bg_download.png",
                                alt: ""
                            })]
                        })
                    })
                })
            }
        },
        90: function(e, t, l) {
            l.d(t, {
                Z: function() {
                    return h
                }
            });
            var r = l(7573),
                n = l(2791),
                a = l(2007),
                c = l.n(a),
                o = ["variant", "color", "size"],
                s = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        fill: t,
                        d: "M12 2C6.49 2 2 6.49 2 12s4.49 10 10 10 10-4.49 10-10S17.51 2 12 2zm1.79 13c.29.29.29.77 0 1.06-.15.15-.34.22-.53.22s-.38-.07-.53-.22L9.2 12.53a.754.754 0 010-1.06l3.53-3.53c.29-.29.77-.29 1.06 0 .29.29.29.77 0 1.06l-3 3 3 3z"
                    }))
                },
                i = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeMiterlimit: "10",
                        strokeWidth: "1.5",
                        d: "M4.87 4.99A9.936 9.936 0 002 12c0 5.52 4.48 10 10 10s10-4.48 10-10S17.52 2 12 2c-.69 0-1.36.07-2.02.2"
                    }), n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "1.5",
                        d: "M13.26 15.53L9.74 12l.96-.97 2.2-2.2.36-.36"
                    }))
                },
                d = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        fill: t,
                        d: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z",
                        opacity: ".4"
                    }), n.createElement("path", {
                        fill: t,
                        d: "M13.26 16.28c-.19 0-.38-.07-.53-.22L9.2 12.53a.754.754 0 010-1.06l3.53-3.53c.29-.29.77-.29 1.06 0 .29.29.29.77 0 1.06l-3 3 3 3c.29.29.29.77 0 1.06a.71.71 0 01-.53.22z"
                    }))
                },
                m = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeMiterlimit: "10",
                        strokeWidth: "1.5",
                        d: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"
                    }), n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "1.5",
                        d: "M13.26 15.53L9.74 12l3.52-3.53"
                    }))
                },
                u = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        fill: t,
                        d: "M12 22.75C6.07 22.75 1.25 17.93 1.25 12S6.07 1.25 12 1.25 22.75 6.07 22.75 12 17.93 22.75 12 22.75zm0-20C6.9 2.75 2.75 6.9 2.75 12S6.9 21.25 12 21.25s9.25-4.15 9.25-9.25S17.1 2.75 12 2.75z"
                    }), n.createElement("path", {
                        fill: t,
                        d: "M13.26 16.28c-.19 0-.38-.07-.53-.22L9.2 12.53a.754.754 0 010-1.06l3.53-3.53c.29-.29.77-.29 1.06 0 .29.29.29.77 0 1.06l-3 3 3 3c.29.29.29.77 0 1.06a.71.71 0 01-.53.22z"
                    }))
                },
                p = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeMiterlimit: "10",
                        strokeWidth: "1.5",
                        d: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"
                    }), n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "1.5",
                        d: "M13.26 15.53L9.74 12l3.52-3.53",
                        opacity: ".4"
                    }))
                },
                h = (0, n.forwardRef)((function(e, t) {
                    var l = e.variant,
                        a = e.color,
                        c = e.size,
                        h = (0, r._)(e, o);
                    return n.createElement("svg", (0, r.a)({}, h, {
                        xmlns: "http://www.w3.org/2000/svg",
                        ref: t,
                        width: c,
                        height: c,
                        viewBox: "0 0 24 24",
                        fill: "none"
                    }), function(e, t) {
                        switch (e) {
                            case "Bold":
                                return n.createElement(s, {
                                    color: t
                                });
                            case "Broken":
                                return n.createElement(i, {
                                    color: t
                                });
                            case "Bulk":
                                return n.createElement(d, {
                                    color: t
                                });
                            case "Linear":
                            default:
                                return n.createElement(m, {
                                    color: t
                                });
                            case "Outline":
                                return n.createElement(u, {
                                    color: t
                                });
                            case "TwoTone":
                                return n.createElement(p, {
                                    color: t
                                })
                        }
                    }(l, a))
                }));
            h.propTypes = {
                variant: c().oneOf(["Linear", "Bold", "Broken", "Bulk", "Outline", "TwoTone"]),
                color: c().string,
                size: c().oneOfType([c().string, c().number])
            }, h.defaultProps = {
                variant: "Linear",
                color: "currentColor",
                size: "24"
            }, h.displayName = "ArrowCircleLeft"
        },
        4570: function(e, t, l) {
            l.d(t, {
                Z: function() {
                    return h
                }
            });
            var r = l(7573),
                n = l(2791),
                a = l(2007),
                c = l.n(a),
                o = ["variant", "color", "size"],
                s = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        fill: t,
                        d: "M12 2C6.49 2 2 6.49 2 12s4.49 10 10 10 10-4.49 10-10S17.51 2 12 2zm2.79 10.53l-3.53 3.53c-.15.15-.34.22-.53.22s-.38-.07-.53-.22a.754.754 0 010-1.06l3-3-3-3a.754.754 0 010-1.06c.29-.29.77-.29 1.06 0l3.53 3.53c.3.29.3.77 0 1.06z"
                    }))
                },
                i = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeMiterlimit: "10",
                        strokeWidth: "1.5",
                        d: "M4.87 4.99A9.936 9.936 0 002 12c0 5.52 4.48 10 10 10s10-4.48 10-10S17.52 2 12 2c-.69 0-1.36.07-2.02.2"
                    }), n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "1.5",
                        d: "M10.74 15.53L14.26 12l-3.52-3.53"
                    }))
                },
                d = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        fill: t,
                        d: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z",
                        opacity: ".4"
                    }), n.createElement("path", {
                        fill: t,
                        d: "M10.74 16.28c-.19 0-.38-.07-.53-.22a.754.754 0 010-1.06l3-3-3-3a.754.754 0 010-1.06c.29-.29.77-.29 1.06 0l3.53 3.53c.29.29.29.77 0 1.06l-3.53 3.53c-.15.15-.34.22-.53.22z"
                    }))
                },
                m = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeMiterlimit: "10",
                        strokeWidth: "1.5",
                        d: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"
                    }), n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "1.5",
                        d: "M10.74 15.53L14.26 12l-3.52-3.53"
                    }))
                },
                u = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        fill: t,
                        d: "M12 22.75C6.07 22.75 1.25 17.93 1.25 12S6.07 1.25 12 1.25 22.75 6.07 22.75 12 17.93 22.75 12 22.75zm0-20C6.9 2.75 2.75 6.9 2.75 12S6.9 21.25 12 21.25s9.25-4.15 9.25-9.25S17.1 2.75 12 2.75z"
                    }), n.createElement("path", {
                        fill: t,
                        d: "M10.74 16.28c-.19 0-.38-.07-.53-.22a.754.754 0 010-1.06l3-3-3-3a.754.754 0 010-1.06c.29-.29.77-.29 1.06 0l3.53 3.53c.29.29.29.77 0 1.06l-3.53 3.53c-.15.15-.34.22-.53.22z"
                    }))
                },
                p = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeMiterlimit: "10",
                        strokeWidth: "1.5",
                        d: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"
                    }), n.createElement("path", {
                        stroke: t,
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "1.5",
                        d: "M10.74 15.53L14.26 12l-3.52-3.53",
                        opacity: ".4"
                    }))
                },
                h = (0, n.forwardRef)((function(e, t) {
                    var l = e.variant,
                        a = e.color,
                        c = e.size,
                        h = (0, r._)(e, o);
                    return n.createElement("svg", (0, r.a)({}, h, {
                        xmlns: "http://www.w3.org/2000/svg",
                        ref: t,
                        width: c,
                        height: c,
                        viewBox: "0 0 24 24",
                        fill: "none"
                    }), function(e, t) {
                        switch (e) {
                            case "Bold":
                                return n.createElement(s, {
                                    color: t
                                });
                            case "Broken":
                                return n.createElement(i, {
                                    color: t
                                });
                            case "Bulk":
                                return n.createElement(d, {
                                    color: t
                                });
                            case "Linear":
                            default:
                                return n.createElement(m, {
                                    color: t
                                });
                            case "Outline":
                                return n.createElement(u, {
                                    color: t
                                });
                            case "TwoTone":
                                return n.createElement(p, {
                                    color: t
                                })
                        }
                    }(l, a))
                }));
            h.propTypes = {
                variant: c().oneOf(["Linear", "Bold", "Broken", "Bulk", "Outline", "TwoTone"]),
                color: c().string,
                size: c().oneOfType([c().string, c().number])
            }, h.defaultProps = {
                variant: "Linear",
                color: "currentColor",
                size: "24"
            }, h.displayName = "ArrowCircleRight"
        },
        7875: function(e, t, l) {
            l.d(t, {
                Z: function() {
                    return h
                }
            });
            var r = l(7573),
                n = l(2791),
                a = l(2007),
                c = l.n(a),
                o = ["variant", "color", "size"],
                s = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        d: "M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10ZM12 14.5c-5.01 0-9.09 3.36-9.09 7.5 0 .28.22.5.5.5h17.18c.28 0 .5-.22.5-.5 0-4.14-4.08-7.5-9.09-7.5Z",
                        fill: t
                    }))
                },
                i = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        d: "M15.02 3.01A4.944 4.944 0 0 0 12 2C9.24 2 7 4.24 7 7s2.24 5 5 5 5-2.24 5-5M20.59 22c0-3.87-3.85-7-8.59-7s-8.59 3.13-8.59 7",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                d = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        opacity: ".4",
                        d: "M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z",
                        fill: t
                    }), n.createElement("path", {
                        d: "M12 14.5c-5.01 0-9.09 3.36-9.09 7.5 0 .28.22.5.5.5h17.18c.28 0 .5-.22.5-.5 0-4.14-4.08-7.5-9.09-7.5Z",
                        fill: t
                    }))
                },
                m = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        d: "M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10ZM20.59 22c0-3.87-3.85-7-8.59-7s-8.59 3.13-8.59 7",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                u = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        d: "M12 12.75c-3.17 0-5.75-2.58-5.75-5.75S8.83 1.25 12 1.25 17.75 3.83 17.75 7s-2.58 5.75-5.75 5.75Zm0-10A4.26 4.26 0 0 0 7.75 7 4.26 4.26 0 0 0 12 11.25 4.26 4.26 0 0 0 16.25 7 4.26 4.26 0 0 0 12 2.75ZM20.59 22.75c-.41 0-.75-.34-.75-.75 0-3.45-3.52-6.25-7.84-6.25S4.16 18.55 4.16 22c0 .41-.34.75-.75.75s-.75-.34-.75-.75c0-4.27 4.19-7.75 9.34-7.75 5.15 0 9.34 3.48 9.34 7.75 0 .41-.34.75-.75.75Z",
                        fill: t
                    }))
                },
                p = function(e) {
                    var t = e.color;
                    return n.createElement(n.Fragment, null, n.createElement("path", {
                        d: "M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), n.createElement("path", {
                        opacity: ".4",
                        d: "M20.59 22c0-3.87-3.85-7-8.59-7s-8.59 3.13-8.59 7",
                        stroke: t,
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }))
                },
                h = (0, n.forwardRef)((function(e, t) {
                    var l = e.variant,
                        a = e.color,
                        c = e.size,
                        h = (0, r._)(e, o);
                    return n.createElement("svg", (0, r.a)({}, h, {
                        xmlns: "http://www.w3.org/2000/svg",
                        ref: t,
                        width: c,
                        height: c,
                        viewBox: "0 0 24 24",
                        fill: "none"
                    }), function(e, t) {
                        switch (e) {
                            case "Bold":
                                return n.createElement(s, {
                                    color: t
                                });
                            case "Broken":
                                return n.createElement(i, {
                                    color: t
                                });
                            case "Bulk":
                                return n.createElement(d, {
                                    color: t
                                });
                            case "Linear":
                            default:
                                return n.createElement(m, {
                                    color: t
                                });
                            case "Outline":
                                return n.createElement(u, {
                                    color: t
                                });
                            case "TwoTone":
                                return n.createElement(p, {
                                    color: t
                                })
                        }
                    }(l, a))
                }));
            h.propTypes = {
                variant: c().oneOf(["Linear", "Bold", "Broken", "Bulk", "Outline", "TwoTone"]),
                color: c().string,
                size: c().oneOfType([c().string, c().number])
            }, h.defaultProps = {
                variant: "Linear",
                color: "currentColor",
                size: "24"
            }, h.displayName = "User"
        },
        7573: function(e, t, l) {
            function r() {
                return r = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var r in l) Object.prototype.hasOwnProperty.call(l, r) && (e[r] = l[r])
                    }
                    return e
                }, r.apply(this, arguments)
            }

            function n(e, t) {
                if (null == e) return {};
                var l, r, n = function(e, t) {
                    if (null == e) return {};
                    var l, r, n = {},
                        a = Object.keys(e);
                    for (r = 0; r < a.length; r++) l = a[r], t.indexOf(l) >= 0 || (n[l] = e[l]);
                    return n
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < a.length; r++) l = a[r], t.indexOf(l) >= 0 || Object.prototype.propertyIsEnumerable.call(e, l) && (n[l] = e[l])
                }
                return n
            }
            l.d(t, {
                _: function() {
                    return n
                },
                a: function() {
                    return r
                }
            })
        }
    }
]);
//# sourceMappingURL=496.dccd9e84.chunk.js.map