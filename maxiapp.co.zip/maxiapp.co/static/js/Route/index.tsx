import Container from 'Component/Container';
import { Footer } from 'Component/Footer';
import { LoadingModal } from 'Component/LoadingModal';
import Company from 'Pages/Company';
import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';

const About = lazy(() => import('Pages/About'));
const Book = lazy(() => import('Pages/Book'));
const Booked = lazy(() => import('Pages/Booked'));
const Home = lazy(() => import('Pages/Home'));
const Linker = lazy(() => import('Pages/Linker/Linker'));
const Login = lazy(() => import('Pages/Login'));
const Privacy = lazy(() => import('Pages/Privacy/Privacy'));
const Specialist = lazy(() => import('Pages/Specialist'));
const Employer = lazy(() => import('Pages/Employer'));
const Employee = lazy(() => import('Pages/Employee'));
const Term = lazy(() => import('Pages/Term/Term'));

export default function RoutePage() {
    return (
        <Suspense fallback={ <LoadingModal></LoadingModal> }>
            <Routes>
                <Route path="/"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Home />
                        </Container>
                    } />
                <Route path="/login"
                    element={
                        <Container>
                            <Login />
                        </Container>
                    } />
                <Route path="/company"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Company />
                        </Container>
                    }
                />
                <Route path="/specialist"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Specialist />
                        </Container>
                    }
                />
                <Route path="/employer"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Employer />
                        </Container>
                    }
                />
                <Route path="/employee"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Employee />
                        </Container>
                    }
                />
                <Route path="/about"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <About />
                        </Container>
                    }
                />
                <Route path="/book"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Book />
                        </Container>
                    }
                />
                <Route path="/booked"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Booked />
                        </Container>
                    }
                />

                <Route path="/privacy"
                    element={
                        <Container footer={ <Footer></Footer> }>
                            <Privacy />
                        </Container>
                    }
                />
                <Route path="/term"
                    element={
                        <Container footer={ <Footer></Footer> }><Term /></Container>
                    }
                />
                <Route path="/download-now" element={ <Linker /> } />
            </Routes>
        </Suspense>
    );
}