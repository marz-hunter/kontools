import { ScrollToTop } from 'Component/ScrollTop';
import { useEffect } from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import RoutePage from 'Route';
import './App.css';

const WOW = require("wow.js");

export default function App() {
  useEffect(() => {
    new WOW().init();
  }, []);

  return (
    <div className="App">
      <ScrollToTop />
      <ToastContainer />
      <RoutePage></RoutePage>
    </div>
  );
}
